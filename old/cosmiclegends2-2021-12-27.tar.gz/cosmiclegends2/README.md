# Cosmic Legends of the Universe

This is a [superhero tabletop roleplaying game](https://spindriftgames.itch.io/cosmic-legends-of-the-universe).

It uses the [Harmony Drive](https://peachgardengames.itch.io/harmony-drive)
system created by [Peach Garden Games](https://peachgardengames.itch.io/).

