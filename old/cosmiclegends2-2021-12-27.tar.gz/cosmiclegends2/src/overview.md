# Overview of Play {#toc-overview .breakbefore}

1. []{.gamename} is played as a series of **Storylines**, each
   taking up one or more game sessions, or **Issues**.

2. Before a new Storyline, the players decide who the **Spotlight**
   hero will be during that Storyline. 

3. The player with the Spotlight tells the Editor what **Opportunity**
   they'd like their hero to experience.

4. The Editor shapes a series of **Crises** that let the Spotlight hero
   work through that Opportunity.

5. Once each player has had the Spotlight to address their 
   hero's Opportunity, that **Volume** of the campaign wraps up
   with an **Annual**.

