# Sample Crises {#toc-sample-crises .colbefore}

These are examples of crises that Editors can use as the backdrops for
Story Arcs.

