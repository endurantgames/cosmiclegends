# Aliens {#toc-sample-aliens}

[]{.lorem}

:::::::::::::: crisis-block :::::::::::::::::::::::::::::::
## Alien Invasion

- **Smash: 6** (destroy the alien ships)
- **Outwit: 5** (trick the aliens into leaving Earth)
- **Allay: 7** ()
- **Rescue: 6** ()

A cluster of alien spaceships is attacking the local shopping
mall, trying to abduct 

Crisis Rules
:   One or more additional rules.

move (a)
:   A description of the move.

move (a)
:   A description of the move.

move (a)
:   A description of the move.

Resolution (Defeat)
:   A description of this resolution.

Resolution (Smash)
:   A description of this resolution.

Resolution (Outwit)
:   A description of this resolution.

Resolution (Allay)
:   A description of this resolution.

Resolution (Rescue)
:   A description of this resolution.

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

