# Science Gone Wild {#toc-sample-science}

[]{.lorem}

:::::::::::::: crisis-block :::::::::::::::::::::::::::::::
## name

- **Smash: v** (desc of goal)
- **Outwit: v** (desc of goal)
- **Allay: v** (desc of goal)
- **Rescue: v** (desc of goal)

desc of crisis

Crisis Rules
:   One or more additional rules.

move (a)
:   A description of the move.

move (a)
:   A description of the move.

move (a)
:   A description of the move.

Resolution (Defeat)
:   A description of this resolution.

Resolution (Smash)
:   A description of this resolution.

Resolution (Outwit)
:   A description of this resolution.

Resolution (Allay)
:   A description of this resolution.

Resolution (Rescue)
:   A description of this resolution.

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

