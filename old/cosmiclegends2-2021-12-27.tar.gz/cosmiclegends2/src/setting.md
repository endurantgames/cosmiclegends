# The Official Handbook of the Cosmic Legends Universe {#toc-setting .breakbefore}

[]{.lorem}

