# Skills {#toc-skills-chargen}

Skills define what your hero does does outside of their life as
a superhero -- they could be from before gaining powers, or they
might be what they still do now.

When you create your hero, your class may give you several Skills
for free; in addition, you have at least 2 free picks.

