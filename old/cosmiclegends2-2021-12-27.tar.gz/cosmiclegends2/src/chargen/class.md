# Hero Class

A hero's *Class* defines broad strokes of their powers, abilities,
and methods. Classes are archetypes that define how your hero fits
into a superhero world.

Each class gives the following:

- Two or more skills
- A class ability
- Two Core Power Words
- Six Personal Power words
- One class ability per Volume

