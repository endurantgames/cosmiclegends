# Hero Origin {#toc-chargen .breakbefore}

To create your hero, you just follow these steps:

1. Pick a Class
   - Pick six Personal Power Words from your Class
   - Pick your Skills, based on your Class
   - Pick a Volume 1 ability from your Class
   - Choose 2 words as your Nova Power
2. Assign 1 point to each Facet, then distribute more 5 points as you wish
3. Pick a Fighting Style
4. Choose 5 words as Ideals
5. Describe a Storyline you'd like to play out with your hero
6. Decide your hero's Appearance and Backstory
   - Choose a Hero Name, Pronouns, and a Real Name; and decide whether the latter is a Secret Identity
   - Describe your Costume, Symbol, and General Appearance

