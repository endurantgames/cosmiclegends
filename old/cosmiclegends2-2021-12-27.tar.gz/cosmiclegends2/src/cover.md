:::::::::::::::::::::::::::::::::::::::::: {#cover} :::::::::::::::::::::::::::::::::::::::::::::::::::
![Cover Image](art/cover.png "Cover Image"){#img-cover} \ 

![Cosmic Legends of the Universe](art/title-image.png "Cosmic Legends of the Universe"){#img-title} \ 

<h1>Cosmic Legends of the Universe</h1>

<h2> The World's Greatest Four-Color TTRPG! </h2>

::::::::::: {#coverbox} :::::::::::::

- Spindrift
- Games
- 1495*&cent;*
- 2021
- SEPT
- *NOT* APPROVED BY THE COMICS CODE AUTHORITY
- &nbsp;
- ?
- ?
- ?
- ?
- ?
:::::::::::::::::::::::::::::::::::::

:::::::::::: {.hype} ::::::::::::::::
- **Who** are the **Legends**?
- **What** are their **Secrets**?
- **How** did they get their **Powers**?
- The **answers** will **shock** you!
:::::::::::::::::::::::::::::::::::::

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
