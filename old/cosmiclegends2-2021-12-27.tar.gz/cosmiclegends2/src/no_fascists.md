:::::::::::::::: {.soapbox #soapbox-no-fascists } :::::::::::::::::::::::::::::::::::::::::::::::::
# No Fascists

If you're a fascist, you're not welcome to play this game. It's against the rules. 

If you're reading this and thinking, "You just call everyone you disagree with a fascist," 
then you're probably a fascist, or incapable of drawing inferences from context and 
acknowledging a dangerous political climate that causes the oppressed to be hyperbolic. 

Don't play this game. Heal yourself. Grow. Learn. 
Watch some [Mister Roger's Neighborhood](https://www.misterrogers.org/) or something.
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

