# "Four-Color"

The term "four-color" refers to the printing process used
in comics that led to most heroes having bold, primary
colors for their uniforms, their bodies, their worlds.

One example is Superman's hair having *blue* overtones --
this was meant to display his hair as a lustrous black
but the capabilities time precluded that.

*Our* use of the term "four-color" doesn't refer to the 
print process for this game but instead to the general tone 
of late Silver Age and Bronze Age comics -- when primary-color 
superheroes of the '50s and '60s met the social issues of 
the '70s and '80s.

