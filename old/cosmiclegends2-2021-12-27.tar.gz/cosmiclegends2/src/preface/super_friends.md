# The Super Friends

In case you didn't notice, this game is inspired by the 
[Super Friends](https://en.wikipedia.org/wiki/Super_Friends)
cartoon show that was on the air from 1973 to 1985 -- also
the years yours truly was age 5 and 16. It's fair to say
the show influenced how I view comics and superheroes
in general.

The first season has this great opening monologue where the four 
heroes were "created from the cosmic legends of the universe!"

What on earth does *that* mean?  How exactly was *Bruce Wayne*
created from the __cosmic legends of the universe__?!
I've never figured that out, but it does make a great title
for this Bronze Age-inspired, four-color tabletop RPG.

