# A Four-Color Bronze Age Superhero TTRPG {.breakbefore #toc-preface}

[]{.lorem}

