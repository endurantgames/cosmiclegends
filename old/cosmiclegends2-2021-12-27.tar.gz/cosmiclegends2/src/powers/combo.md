# Power Combos {#toc-power-combos }

A **Power Combo** is a Power Stunt where two or more heroes work
together, with their powers combined. 

To use a Power Combo, ask one of your fellow players if they'd
like to form a Power Combo with you and tell them what you're trying
to accomplish. Together you describe the action your heroes are
taking and how their powers work to produce the needed effect.

You can invite as many players to join in as you like, as long
as you can come up with an explanation of how they're helping.

The players decide whose hero is central to the Power Combo, 
and they're called the initiating hero for that Combo.

A Power Combo starts with a Power Stunt -- the player of the
initiating hero chooses two Power Words and combines them,
spending 1 point of Might and increasing the number of dice
of their next roll by 1 Success.

The other players each spend 1 Might and contribute another
Power Word to the Power Combo, each of which adds a die to the
dice pool.

Only the initiating hero can spend additional Might to use one 
of their Core Power Words as a *third* (or fourth) Power Word in 
the Combo.

For example, []{.lorem}

