# Power Displays {#toc-power-displays}

When you want your hero to use their powers, you pick one Power Word
and explain how you're using that power.

A Power Display doesn't cost any Might points.

Power Displays don't have a game-mechanics effect on your rolls, but you
can use them to explain how you're able to *make* those rolls. 

For example, if a villain is flying over the city, you could describe it
as a Power Display using your Power Word of Flight when you take to 
the skies to throw a punch. 

If you don't have Flight as a Power Word, but you have Line, your
Display could describe how you hook your swingline onto a nearby 
skyscraper to deliver two boots to the face.
