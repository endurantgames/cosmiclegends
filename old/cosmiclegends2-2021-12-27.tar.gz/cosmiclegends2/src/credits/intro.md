# Game Credits {#toc-credits .breakbefore}

This game was created by <a href="mailto:caderaspindrift@gmail.com">Cadera Spindrift</a>.

