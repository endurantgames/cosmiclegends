The contents of the game are covered by the
*Anti-Capitalist Attirbution Cooperative License* found at the end of the rules.

