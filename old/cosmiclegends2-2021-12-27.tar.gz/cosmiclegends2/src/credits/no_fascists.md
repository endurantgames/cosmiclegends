*No Fascists* rule by <a href="https://machineage.tokyo/olivia-hill-rule/">Olivia Hill</a>, 
licensed under <a href="https://creativecommons.org/licenses/by-sa/4.0/legalcode"
>Creative Commons Attribution Share-Alike 4.0</a>.

