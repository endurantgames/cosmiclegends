This work is based on the Harmony Drive system from 
[Cat McDonald](https://peachgardengames.itch.io/harmony-drive) and 
[Peach Garden Games](https://peachgardengames.itch.io/), and 
licensed for use under the 
[Creative Commons Attribution 3.0 Unported license](http:// creativecommons.org/licenses/by/3.0/).

*The Driven by Harmony* logo is &copy; Cat McDonald, 
and is used with permission.

