# Ethos {#toc-ethos .colbefore}

[]{.gamename} revolves around the following three pillars:

## Self Expression

The Power Word system and Crisis system are intentionally built to 
give players freedom to engage with problems in their own style. 
[]{.gamename} lets you be yourself, and do things in your own way, 
without being left behind by your team.

## Teamwork

[]{.gamename} games is written to encourage the players to work 
together. Whether you're combining your powers to use Power Combos
or using your skills to overcome an opponent together, heroes in 
[]{.gamename} succeed or fail as a team.

## Difficult Choices

The Edge Success system is built so that you have the freedom 
to choose failure. The Crisis system is built so that you can 
choose to take big hits. Good things and bad things happen to
your hero, and both of these are in the your hands to choose. 
The Editor’s job is to give you those difficult choices.

