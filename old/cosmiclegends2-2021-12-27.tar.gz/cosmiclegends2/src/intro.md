# Cosmic Legends of the Universe

> In the great Hall of Heroes are assembled the world's greatest
> superheroes: the Cosmic Legends of the Universe!

<div class="harmony-drive-logo">
  <a href="https://peachgardengames.itch.io/harmony-drive">
    <img src="art/DrivenByHarmonyLogo.png" alt="Driven By Harmony" />
  </a>
</div>

[]{.gamename} is a four-color tabletop roleplaying game where
you and your friends take the roles of super-powered heroes
who fight against injustice, right that which is wrong, and serve
all mankind.

The *[Harmony Drive](https://peachgardengames.itch.io/harmony-drive)*
system created by Cat McDonald is at the heart of []{.gamename}.

## What You Need

To play []{.gamename} you'll need:

- One player, playing as the Editor
- Two to six other players
- A copy of these game rules
- At least a half-dozen six-sided dice
- One hero sheet per player
- Pencils
- A few hours
- Your imagination!

