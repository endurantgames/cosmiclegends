::::::::::::::: pieces-list ::::::::::::::::::
<label for="pieces-current">Chord:</label>

:::::::::::::: pieces-display ::::::::::::::::::::::::::::::::::::::::::
<input type="text" class="pieces-current" name="pieces-current"></input>
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

:::::::::::::: { pieces-list nav-buttons } :::::::::::::::::::::::::::::::::::
<button>Save</button>                                   <button>Reset</button>
<button>Remember</button>                               <button> Load</button>
<input type="text" class="pieces-current cost"></input> <button>  Pay</button>
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

<label for="piece-1"></label><label for="piece-1-button" class="piece-add" ></label><button name="piece-1-button" class="piece-button"></button><input type="text" name="piece-1"></input>
<label for="piece-2"></label><label for="piece-2-button" class="piece-add" ></label><button name="piece-2-button" class="piece-button"></button><input type="text" name="piece-2"></input>
<label for="piece-3"></label><label for="piece-3-button" class="piece-add" ></label><button name="piece-3-button" class="piece-button"></button><input type="text" name="piece-3"></input>
<label for="piece-4"></label><label for="piece-4-button" class="piece-add" ></label><button name="piece-4-button" class="piece-button"></button><input type="text" name="piece-4"></input>
<label for="piece-5"></label><label for="piece-5-button" class="piece-add" ></label><button name="piece-5-button" class="piece-button"></button><input type="text" name="piece-5"></input>
<label for="piece-6"></label><label for="piece-6-button" class="piece-add" ></label><button name="piece-6-button" class="piece-button"></button><input type="text" name="piece-6"></input>
:::::::::::::::::::::::::::::::::::::::::::::::
