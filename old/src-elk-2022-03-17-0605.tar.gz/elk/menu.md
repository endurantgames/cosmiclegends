<label for="main-menu" class="main-menu label">Main Menu</label>

<select name="main-menu"   class="main-menu">
  <option value="main"    >Main              </option>
  <option value="scatter" >Scatter some Magic</option>
  <option value="roller"  >Dice Roller       </option>
  <option value="builder" >Character Editor  </option>
  <option value="settings">Settings          </option>
  <option value="games"   >Get Games         </option>
  <option value="send"    >Send Some Harmony </option>
  <option value="stuff"   >Inventory         </option>
</select>

