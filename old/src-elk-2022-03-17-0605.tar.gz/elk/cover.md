::::: {#cover} ::::::::::::::::::::::::::::::::::::::::::::::
![Cover Image](art/cover.png "Cover Image"){#img-cover} \ 
![Cloud Elk]("Cloud Elk"){#img-title} \ 

<button id="cover-button">Summon Cloud Elk</button> \

<h1>Cloud-Elk</h1>
<h2>A Harmonic Character Editor!</h2>

:::::::::::: {.hype} ::::::::::::::::
- **This Elk is *Driven By Harmony!**
- **Compatible with:** 
  - Harmonic Chord
  - Cosmic Legends of the Universe
  - Harmony Drive SRD
  - *Portes*, un hommage à Douglas Adams, 
    ses œuvres, sa ville et ses tiroirs
- **How** did they get their **Powers**?
- The **answers** will **shock** you!
:::::::::::::::::::::::::::::::::::::

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
