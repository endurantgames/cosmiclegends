::::::::::::::: { #elk .credits } :::::::::::::::::::::::::
# Cloud Elk: Credits

- Cloud Elk software created by
  [Dera "Dox-El" Spindrift](http://spindriftgames.itch.io){.linkto .dera}
- Harmonic Chord system created by
  [Cat ]{.linkto .cat}
- Cosmic Legends of the Universe TTRPG created by
  [Spindrift Games](http://spindriftgames.itch.io){.linkto .spindrift}
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
